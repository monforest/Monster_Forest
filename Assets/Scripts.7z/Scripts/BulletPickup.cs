﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BulletPickup : CollectableItems
{ 
    public Item item;

    PlayerStats playerStats;

	// Use this for initialization
	void Start () {
        playerStats = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerStats>();
    }

    public override void Interact()
    { 
        item.Use();

        Destroy(gameObject);
    }
}
