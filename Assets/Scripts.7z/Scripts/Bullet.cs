﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "New Crystal", menuName = "Item/Bullet")]
public class Bullet : Item
{

    public int damageToPlayer;

    PlayerStats playerStats;

    void Start()
    {
        playerStats = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerStats>();
    }

    public override void Use()
    {
        base.Use();
        playerStats.TakeDamage(damageToPlayer);

    }

}
