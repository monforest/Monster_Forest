﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FlowerPickup : CollectableItems {

    public Item item;

    PlayerStats playerStats;

	void Start ()
    {
        playerStats = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerStats>();	
	}


    public override void Interact()
    {
        base.Interact();
        //flower animation ON
        item.Use();
    }

    
}
