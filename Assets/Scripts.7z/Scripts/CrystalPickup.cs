﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CrystalPickup : CollectableItems
{
    void Update()
    {
        transform.Rotate(new Vector3(0, 45, 0) * Time.deltaTime);

        if (GameControl.gameControl.gameOver)
        {
            gameObject.SetActive(true);
        }
    }

    public override void Interact()
    {
        base.Interact();
        gameObject.SetActive(false);
    }
}
