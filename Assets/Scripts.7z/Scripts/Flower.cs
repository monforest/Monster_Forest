﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


[CreateAssetMenu(fileName = "New Crystal", menuName = "Item/Flower")]
public class Flower : Item
{ 
    public int healthModifier;

    PlayerStats playerStats;

    void Start()
    {
        playerStats = GameObject.FindGameObjectWithTag("Player").GetComponent<PlayerStats>();
    }

    public override void Use()
    {
        base.Use();
        playerStats.ModifyHealth(healthModifier);

    }
   
}
